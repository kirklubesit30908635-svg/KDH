# Intercompany Transfer Pricing Policy
## Kirk Digital Holdings LLC Corporate Group

**Policy Version:** 1.0
**Effective Date:** _______________
**Prepared by:** Chase Kirk, Founder
**Entities Covered:** Kirk Digital Holdings LLC · AutoKirk IP Holdings LLC · AutoKirk Systems LLC

---

## 1. Purpose

This policy documents the intercompany pricing arrangements between the entities of the Kirk Digital Holdings LLC corporate group (collectively, the "Group"). It establishes that all intercompany transactions are conducted at arm's-length rates consistent with what unrelated parties would agree to in similar circumstances, as required under applicable tax regulations.

This policy should be maintained and updated annually or whenever the Group's licensing structure materially changes.

---

## 2. Entity Roles and Functions

| Entity | Role | Functions Performed | Assets Owned | Risks Borne |
|---|---|---|---|---|
| Kirk Digital Holdings LLC (KDH) | Parent / Governance | Strategic oversight, capital allocation, founder governance | Equity interests in subsidiaries | Investment risk, strategic risk |
| AutoKirk IP Holdings LLC (AK-IP) | IP Owner / Licensor | IP development oversight, licensing administration, royalty collection | AutoKirk Kernel IP (code, schemas, doctrine, architecture, marks) | IP development risk, licensing credit risk |
| AutoKirk Systems LLC (AK-Systems) | Operator / Distributor | Software deployment, operator sales, customer support, platform operations | Operational assets, customer contracts | Operational risk, customer credit risk, execution risk |

---

## 3. Intercompany Transactions

### 3.1 AK-IP → AK-Systems: Kernel IP License

**Transaction:** AK-IP licenses the AutoKirk Kernel (including all Faces, schemas, RPCs, and associated IP) to AK-Systems for distribution to operators.

**Royalty Rate:** 20% of AK-Systems' gross Monthly License Fee revenue from each operator.

**Rationale for 20% Rate:**

The 20% royalty rate reflects the following factors:

(a) *Comparable uncontrolled transactions.* Software IP royalty rates in the B2B SaaS and platform licensing market typically range from 15% to 35% of revenue for foundational platform IP. The 20% rate falls within the lower end of this range, reflecting that AK-Systems bears significant operational risk and customer acquisition costs.

(b) *Functional analysis.* AK-IP performs no sales, marketing, or support functions. AK-Systems performs all customer-facing functions, bears churn risk, and manages deployments. The 20% royalty compensates AK-IP for owning the Kernel while leaving adequate margin with AK-Systems for its operational functions.

(c) *Value of licensed IP.* The Kernel provides the immutable enforcement infrastructure that differentiates the product. Without it, AK-Systems could not operate. The 20% royalty reflects this foundational but non-operational contribution.

(d) *Comparable license structures.* Platform licensing arrangements in similar enforcement/compliance SaaS companies (e.g., workflow automation platforms licensing their core engine to operating subsidiaries) commonly use 15–25% royalty rates.

### 3.2 AK-IP → KDH: Governance Fee

**Transaction:** AK-IP pays KDH a monthly governance fee for strategic oversight, capital support, and parent-level administration provided by KDH.

**Fee Rate:** 10% of AK-IP's gross royalty receipts from AK-Systems.

**Effective Rate on Operator Revenue:** 2% of AK-Systems' operator MRR (10% × 20%).

**Rationale for 10% Rate:**

(a) *Management fee benchmarks.* Parent company management fees for strategic oversight typically range from 5% to 15% of subsidiary revenue. The 10% rate is mid-range.

(b) *Services provided by KDH.* KDH provides: (i) founder governance and strategic direction; (ii) capital formation and funding; (iii) entity-level compliance and administration; (iv) inter-subsidiary coordination. These are real services with economic value.

(c) *No markup on cost.* The fee is not intended to generate profit at the KDH level above a cost-recovery basis during the early stage of operations. As KDH's oversight burden scales, this rate will be reviewed.

---

## 4. Invoicing and Settlement

- AK-Systems invoices operators on the 1st of each month.
- AK-Systems remits the 20% royalty to AK-IP within 10 business days of collection.
- AK-IP remits the 10% governance fee to KDH within 5 business days of receiving the royalty payment.
- All intercompany payments are documented with written invoices referencing this policy.
- All royalty flows generate a corresponding ledger receipt in the AutoKirk Kernel (`ledger.receipts`), providing an immutable audit trail.

---

## 5. Third-Party License Arrangements

For white-label or third-party developer licenses issued directly by AK-IP:

- Annual flat fee: $12,000 per license
- Revenue share: 15% of licensee's gross revenue from deployments using the Kernel
- KDH governance fee: 10% of AK-IP's receipts from third-party licenses (same rate as operator royalties)

---

## 6. Review and Updates

This policy will be reviewed:
- Annually, no later than December 31 of each year
- Upon any material change to the Group's revenue, structure, or licensing arrangements
- Upon entry into any new jurisdiction that imposes transfer pricing documentation requirements

---

## 7. Documentation Maintained

The Group maintains the following supporting documentation:
- This Transfer Pricing Policy
- The IP Assignment Agreement (Chase Kirk / KDH → AK-IP)
- The Intercompany License Agreement (AK-IP → AK-Systems)
- Monthly royalty invoices and payment records
- Ledger receipts from the AutoKirk Kernel for each royalty transaction

---

*This policy was prepared for internal governance purposes. Consult a qualified tax advisor regarding transfer pricing compliance in applicable jurisdictions.*

---

**Approved by:**

Chase Kirk, Founder — Kirk Digital Holdings LLC

Signature: _______________________________ Date: _______________
