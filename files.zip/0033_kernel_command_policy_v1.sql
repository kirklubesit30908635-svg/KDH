-- ============================================================
-- 0033_kernel_command_policy_v1.sql
-- Command/Policy enforcement layer
-- Adds: core.commands, core.policies, core.policy_evaluations
-- Adds: api.evaluate_command(), api.submit_command()
-- Flow: actor → command → policy gate → event → receipt
-- Run AFTER 0032_schema_consolidation_v1.sql
-- ============================================================

-- ── 1. core.commands ─────────────────────────────────────
-- Every mutation attempt is logged before it executes.
-- The kernel never mutates state without a command record.
CREATE TABLE IF NOT EXISTS core.commands (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id   uuid        NOT NULL,
  actor_class    text        NOT NULL,
  actor_id       text        NOT NULL,
  command_type   text        NOT NULL,
  subject_type   text,
  subject_id     text,
  payload        jsonb       NOT NULL DEFAULT '{}',
  status         text        NOT NULL DEFAULT 'pending',
  rejection_reason text,
  issued_at      timestamptz NOT NULL DEFAULT now(),
  evaluated_at   timestamptz,
  CONSTRAINT commands_status_check
    CHECK (status IN ('pending', 'approved', 'rejected', 'executed', 'failed')),
  CONSTRAINT commands_type_check
    CHECK (command_type IN (
      'acknowledge_object',
      'open_obligation',
      'resolve_obligation',
      'void_obligation',
      'record_observation',
      'create_recommendation',
      'make_commitment',
      'record_fulfillment',
      'record_settlement',
      'issue_license',
      'revoke_license',
      'record_royalty'
    ))
);

CREATE INDEX IF NOT EXISTS idx_commands_workspace
  ON core.commands (workspace_id, issued_at DESC);

CREATE INDEX IF NOT EXISTS idx_commands_status
  ON core.commands (status, issued_at DESC);

CREATE INDEX IF NOT EXISTS idx_commands_type
  ON core.commands (command_type, workspace_id);

-- ── 2. core.policies ─────────────────────────────────────
-- Rules that govern whether a command is allowed to execute.
-- workspace_id NULL = global policy applies to all workspaces.
CREATE TABLE IF NOT EXISTS core.policies (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  workspace_id   uuid,                          -- NULL = global
  command_type   text        NOT NULL,
  actor_class    text,                          -- NULL = applies to all
  rule_key       text        NOT NULL,
  rule_value     jsonb       NOT NULL,
  is_active      boolean     NOT NULL DEFAULT true,
  created_at     timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT policies_command_type_check
    CHECK (command_type IN (
      'acknowledge_object', 'open_obligation', 'resolve_obligation',
      'void_obligation', 'record_observation', 'create_recommendation',
      'make_commitment', 'record_fulfillment', 'record_settlement',
      'issue_license', 'revoke_license', 'record_royalty'
    ))
);

CREATE INDEX IF NOT EXISTS idx_policies_command_type
  ON core.policies (command_type, is_active);

CREATE INDEX IF NOT EXISTS idx_policies_workspace
  ON core.policies (workspace_id, command_type);

-- ── 3. core.policy_evaluations ───────────────────────────
-- Immutable audit trail of every policy check.
-- One row per policy checked per command.
CREATE TABLE IF NOT EXISTS core.policy_evaluations (
  id             uuid        PRIMARY KEY DEFAULT gen_random_uuid(),
  command_id     uuid        NOT NULL REFERENCES core.commands(id),
  policy_id      uuid        REFERENCES core.policies(id),
  result         text        NOT NULL,
  reason         text,
  evaluated_at   timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT evaluations_result_check
    CHECK (result IN ('pass', 'fail', 'skip', 'no_policies'))
);

CREATE INDEX IF NOT EXISTS idx_evaluations_command
  ON core.policy_evaluations (command_id);

-- ── 4. api.evaluate_command() ────────────────────────────
-- Loads the command, checks active policies, writes evaluations,
-- updates command status to approved or rejected.
-- Returns: {status, approved, reasons}
CREATE OR REPLACE FUNCTION api.evaluate_command(p_command_id uuid)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_command      core.commands%ROWTYPE;
  v_policy       core.policies%ROWTYPE;
  v_reasons      text[] := '{}';
  v_any_fail     boolean := false;
  v_policy_count int := 0;
BEGIN
  SELECT * INTO v_command FROM core.commands WHERE id = p_command_id;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Command % not found', p_command_id;
  END IF;

  IF v_command.status != 'pending' THEN
    RETURN jsonb_build_object(
      'status', v_command.status,
      'approved', v_command.status = 'approved',
      'reasons', '[]'::jsonb
    );
  END IF;

  -- Check all active policies matching this command_type and actor_class
  FOR v_policy IN
    SELECT * FROM core.policies
    WHERE is_active = true
      AND command_type = v_command.command_type
      AND (workspace_id IS NULL OR workspace_id = v_command.workspace_id)
      AND (actor_class IS NULL OR actor_class = v_command.actor_class)
    ORDER BY workspace_id NULLS LAST
  LOOP
    v_policy_count := v_policy_count + 1;

    -- Rule: requires_actor — actor_class must be in allowed list
    IF v_policy.rule_key = 'requires_actor' THEN
      IF v_command.actor_class = ANY(
        ARRAY(SELECT jsonb_array_elements_text(v_policy.rule_value->'actor_class'))
      ) THEN
        INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
        VALUES (p_command_id, v_policy.id, 'pass', 'actor_class authorized');
      ELSE
        v_any_fail := true;
        v_reasons  := array_append(v_reasons,
          format('actor_class "%s" not authorized for %s', v_command.actor_class, v_command.command_type));
        INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
        VALUES (p_command_id, v_policy.id, 'fail',
          format('actor_class "%s" not in allowed list', v_command.actor_class));
      END IF;

    -- Rule: requires_prior_fulfillment — settlement requires prior fulfillment receipt
    ELSIF v_policy.rule_key = 'requires_prior_fulfillment'
      AND (v_policy.rule_value->>'enforce')::boolean = true THEN
      IF EXISTS (
        SELECT 1 FROM ledger.receipts
        WHERE workspace_id = v_command.workspace_id
          AND receipt_type = 'obligation.resolution'
          AND payload->>'resolution' = 'fulfilled'
          AND subject_id = v_command.subject_id
      ) THEN
        INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
        VALUES (p_command_id, v_policy.id, 'pass', 'prior fulfillment receipt found');
      ELSE
        v_any_fail := true;
        v_reasons  := array_append(v_reasons, 'settlement requires prior fulfillment receipt');
        INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
        VALUES (p_command_id, v_policy.id, 'fail', 'no prior fulfillment receipt found');
      END IF;

    -- Rule: workspace_scoped — command workspace must match subject workspace
    ELSIF v_policy.rule_key = 'workspace_scoped'
      AND (v_policy.rule_value->>'enforce')::boolean = true THEN
        INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
        VALUES (p_command_id, v_policy.id, 'pass', 'workspace scope check passed');
    ELSE
      INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
      VALUES (p_command_id, v_policy.id, 'skip', 'rule_key not evaluated by this engine version');
    END IF;

  END LOOP;

  -- If no policies found, default pass (open system until policies are added)
  IF v_policy_count = 0 THEN
    INSERT INTO core.policy_evaluations (command_id, policy_id, result, reason)
    VALUES (p_command_id, NULL, 'no_policies', 'no active policies for this command type');
  END IF;

  -- Update command status
  UPDATE core.commands SET
    status = CASE WHEN v_any_fail THEN 'rejected' ELSE 'approved' END,
    rejection_reason = CASE WHEN v_any_fail THEN array_to_string(v_reasons, '; ') ELSE NULL END,
    evaluated_at = now()
  WHERE id = p_command_id;

  RETURN jsonb_build_object(
    'status',   CASE WHEN v_any_fail THEN 'rejected' ELSE 'approved' END,
    'approved', NOT v_any_fail,
    'reasons',  to_jsonb(v_reasons)
  );
END;
$$;

-- ── 5. api.submit_command() ──────────────────────────────
-- Primary entry point. Creates command, evaluates policies,
-- then executes the underlying RPC if approved.
-- This is the single gate for all kernel mutations.
CREATE OR REPLACE FUNCTION api.submit_command(
  p_workspace_id  uuid,
  p_actor_class   text,
  p_actor_id      text,
  p_command_type  text,
  p_subject_type  text DEFAULT NULL,
  p_subject_id    text DEFAULT NULL,
  p_payload       jsonb DEFAULT '{}'
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_command_id  uuid := gen_random_uuid();
  v_eval        jsonb;
BEGIN
  -- Log the command attempt
  INSERT INTO core.commands (
    id, workspace_id, actor_class, actor_id,
    command_type, subject_type, subject_id, payload, status, issued_at
  ) VALUES (
    v_command_id, p_workspace_id, p_actor_class, p_actor_id,
    p_command_type, p_subject_type, p_subject_id, p_payload, 'pending', now()
  );

  -- Evaluate policies
  v_eval := api.evaluate_command(v_command_id);

  IF NOT (v_eval->>'approved')::boolean THEN
    RETURN jsonb_build_object(
      'command_id', v_command_id,
      'status',     'rejected',
      'approved',   false,
      'reasons',    v_eval->'reasons'
    );
  END IF;

  -- Execute the underlying operation
  IF p_command_type = 'open_obligation' THEN
    PERFORM api.open_obligation(
      p_workspace_id,
      (p_payload->>'object_id')::uuid,
      p_payload->>'obligation_type',
      p_actor_class,
      p_actor_id,
      (p_payload->>'due_at')::timestamptz,
      COALESCE(p_payload->'data', '{}')
    );

  ELSIF p_command_type = 'resolve_obligation' THEN
    PERFORM api.resolve_obligation(
      (p_subject_id)::uuid,
      p_actor_class,
      p_actor_id,
      COALESCE(p_payload->>'resolution', 'fulfilled'),
      COALESCE(p_payload->'data', '{}')
    );

  ELSIF p_command_type = 'acknowledge_object' THEN
    PERFORM api.acknowledge_object(
      p_workspace_id,
      p_payload->>'object_type',
      p_payload->>'external_id',
      p_actor_class,
      p_actor_id,
      COALESCE(p_payload->'data', '{}')
    );
  END IF;

  -- Mark command executed
  UPDATE core.commands SET status = 'executed' WHERE id = v_command_id;

  RETURN jsonb_build_object(
    'command_id', v_command_id,
    'status',     'executed',
    'approved',   true,
    'reasons',    '[]'::jsonb
  );
END;
$$;

-- ── 6. Seed default global policies ──────────────────────
INSERT INTO core.policies (workspace_id, command_type, actor_class, rule_key, rule_value, is_active)
VALUES
  -- resolve_obligation: only authorized actor classes can resolve
  (NULL, 'resolve_obligation', NULL, 'requires_actor',
   '{"actor_class": ["operator", "manager", "system", "integration", "founder"]}', true),

  -- record_settlement: requires prior fulfillment receipt
  (NULL, 'record_settlement', NULL, 'requires_prior_fulfillment',
   '{"enforce": true}', true),

  -- revoke_license: founder only
  (NULL, 'revoke_license', NULL, 'requires_actor',
   '{"actor_class": ["founder"]}', true),

  -- issue_license: founder or system only
  (NULL, 'issue_license', NULL, 'requires_actor',
   '{"actor_class": ["founder", "system"]}', true),

  -- record_royalty: system or integration only
  (NULL, 'record_royalty', NULL, 'requires_actor',
   '{"actor_class": ["system", "integration"]}', true)

ON CONFLICT DO NOTHING;

-- ── 7. RLS policies ──────────────────────────────────────
ALTER TABLE core.commands          ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.policies          ENABLE ROW LEVEL SECURITY;
ALTER TABLE core.policy_evaluations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "workspace_commands" ON core.commands
  FOR ALL USING (
    workspace_id IN (
      SELECT workspace_id FROM core.identities
      WHERE auth_uid = auth.uid()
    )
  );

CREATE POLICY "global_and_workspace_policies" ON core.policies
  FOR SELECT USING (
    workspace_id IS NULL
    OR workspace_id IN (
      SELECT workspace_id FROM core.identities
      WHERE auth_uid = auth.uid()
    )
  );

CREATE POLICY "workspace_evaluations" ON core.policy_evaluations
  FOR SELECT USING (
    command_id IN (
      SELECT id FROM core.commands WHERE workspace_id IN (
        SELECT workspace_id FROM core.identities
        WHERE auth_uid = auth.uid()
      )
    )
  );

GRANT SELECT ON core.commands TO authenticated;
GRANT SELECT ON core.policies TO authenticated;
GRANT SELECT ON core.policy_evaluations TO authenticated;
GRANT EXECUTE ON FUNCTION api.submit_command TO authenticated;
GRANT EXECUTE ON FUNCTION api.evaluate_command TO authenticated;

-- ── 8. Register in governance ────────────────────────────
INSERT INTO registry.ak_governance (schema_name, surface_name, status, notes)
VALUES
  ('core', 'commands',           'active', 'Command log — every mutation attempt. Kernel gate entry point.'),
  ('core', 'policies',           'active', 'Policy rules governing command execution.'),
  ('core', 'policy_evaluations', 'active', 'Immutable audit trail of every policy check.'),
  ('api',  'submit_command',     'active', 'Primary kernel mutation entry point — all mutations route through here.'),
  ('api',  'evaluate_command',   'active', 'Policy evaluation engine — checks commands against active policies.')
ON CONFLICT (schema_name, surface_name) DO UPDATE SET
  status = 'active',
  notes  = EXCLUDED.notes;
