-- ============================================================
-- Migration: 0032_ak_ip_registry.sql
-- Purpose:   AutoKirk IP Holdings licensing infrastructure
--            License issuance, royalty ledger, entitlement tracking
-- Applies to: autokirk-kernel (Supabase instance: ihkymfqyfbvsogdprris)
-- ============================================================

-- ── Schema ──────────────────────────────────────────────────
CREATE SCHEMA IF NOT EXISTS ak_ip;
GRANT USAGE ON SCHEMA ak_ip TO authenticated, anon;

-- ── License tiers ────────────────────────────────────────────
CREATE TYPE ak_ip.license_tier AS ENUM ('seed', 'operator', 'enterprise', 'third_party');
CREATE TYPE ak_ip.license_state AS ENUM ('active', 'suspended', 'terminated', 'pending');
CREATE TYPE ak_ip.royalty_state AS ENUM ('pending', 'collected', 'remitted', 'voided');

-- ── Issued licenses ──────────────────────────────────────────
-- One row per operator license issued by AK-IP (via AK-Systems)
CREATE TABLE ak_ip.licenses (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id           uuid NOT NULL REFERENCES core.tenants(id) ON DELETE RESTRICT,
  license_tier        ak_ip.license_tier NOT NULL,
  state               ak_ip.license_state NOT NULL DEFAULT 'active',

  -- Financial terms
  monthly_fee_cents   integer NOT NULL CHECK (monthly_fee_cents > 0),
  royalty_rate_bps    integer NOT NULL DEFAULT 2000   -- 2000 bps = 20%
                      CHECK (royalty_rate_bps BETWEEN 0 AND 10000),
  kdh_fee_rate_bps    integer NOT NULL DEFAULT 1000   -- 1000 bps = 10% of royalty
                      CHECK (kdh_fee_rate_bps BETWEEN 0 AND 10000),

  -- Version pinning
  kernel_migration_version integer NOT NULL,          -- highest migration # at issuance
  licensed_faces      text[] NOT NULL DEFAULT '{}',   -- e.g. ARRAY['dealership','advertising']

  -- Metadata
  effective_date      date NOT NULL DEFAULT CURRENT_DATE,
  termination_date    date,
  notes               text,

  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX ON ak_ip.licenses (tenant_id);
CREATE INDEX ON ak_ip.licenses (state);
CREATE INDEX ON ak_ip.licenses (effective_date);

-- ── Royalty events ────────────────────────────────────────────
-- One row per billing cycle per license
CREATE TABLE ak_ip.royalty_events (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  license_id          uuid NOT NULL REFERENCES ak_ip.licenses(id) ON DELETE RESTRICT,
  tenant_id           uuid NOT NULL REFERENCES core.tenants(id) ON DELETE RESTRICT,

  -- Billing period
  period_start        date NOT NULL,
  period_end          date NOT NULL,

  -- Amounts (all in cents)
  gross_fee_cents     integer NOT NULL CHECK (gross_fee_cents >= 0),
  royalty_cents       integer NOT NULL CHECK (royalty_cents >= 0),   -- gross * royalty_rate_bps / 10000
  kdh_fee_cents       integer NOT NULL CHECK (kdh_fee_cents >= 0),   -- royalty * kdh_fee_rate_bps / 10000
  ak_ip_net_cents     integer NOT NULL CHECK (ak_ip_net_cents >= 0), -- royalty - kdh_fee
  ak_systems_net_cents integer NOT NULL CHECK (ak_systems_net_cents >= 0), -- gross - royalty

  state               ak_ip.royalty_state NOT NULL DEFAULT 'pending',

  -- Stripe references
  stripe_invoice_id   text,
  stripe_payment_intent_id text,

  -- Ledger linkage (receipt written when remitted)
  ledger_receipt_id   uuid REFERENCES ledger.receipts(id),

  collected_at        timestamptz,
  remitted_at         timestamptz,
  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now(),

  CONSTRAINT no_period_overlap UNIQUE (license_id, period_start)
);

CREATE INDEX ON ak_ip.royalty_events (license_id);
CREATE INDEX ON ak_ip.royalty_events (tenant_id);
CREATE INDEX ON ak_ip.royalty_events (state);
CREATE INDEX ON ak_ip.royalty_events (period_start);

-- ── Third-party developer licenses ───────────────────────────
CREATE TABLE ak_ip.third_party_licenses (
  id                  uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  licensee_name       text NOT NULL,
  licensee_entity     text,
  contact_email       text NOT NULL,
  state               ak_ip.license_state NOT NULL DEFAULT 'pending',

  annual_fee_cents    integer NOT NULL DEFAULT 1200000,  -- $12,000
  rev_share_bps       integer NOT NULL DEFAULT 1500,     -- 15%
  kernel_migration_version integer NOT NULL,

  effective_date      date NOT NULL DEFAULT CURRENT_DATE,
  expiry_date         date,
  notes               text,

  created_at          timestamptz NOT NULL DEFAULT now(),
  updated_at          timestamptz NOT NULL DEFAULT now()
);

-- ── Entitlement view ─────────────────────────────────────────
-- Fast lookup: is this tenant licensed? what faces? what version?
CREATE VIEW ak_ip.entitlements AS
SELECT
  l.tenant_id,
  t.name                          AS tenant_name,
  t.slug                          AS tenant_slug,
  l.id                            AS license_id,
  l.license_tier,
  l.state                         AS license_state,
  l.licensed_faces,
  l.kernel_migration_version,
  l.monthly_fee_cents,
  l.royalty_rate_bps,
  l.effective_date,
  l.termination_date,
  (l.state = 'active'
    AND (l.termination_date IS NULL OR l.termination_date >= CURRENT_DATE)
  )                               AS is_entitled
FROM ak_ip.licenses l
JOIN core.tenants t ON t.id = l.tenant_id;

-- ── Royalty summary view ──────────────────────────────────────
CREATE VIEW ak_ip.royalty_summary AS
SELECT
  date_trunc('month', re.period_start)           AS month,
  COUNT(DISTINCT re.license_id)                  AS active_licenses,
  SUM(re.gross_fee_cents)                        AS gross_mrr_cents,
  SUM(re.royalty_cents)                          AS total_royalty_cents,
  SUM(re.kdh_fee_cents)                          AS kdh_fee_cents,
  SUM(re.ak_ip_net_cents)                        AS ak_ip_net_cents,
  SUM(re.ak_systems_net_cents)                   AS ak_systems_net_cents,
  COUNT(*) FILTER (WHERE re.state = 'remitted')  AS remitted_count,
  COUNT(*) FILTER (WHERE re.state = 'pending')   AS pending_count
FROM ak_ip.royalty_events re
GROUP BY 1
ORDER BY 1 DESC;

-- ── RPCs ──────────────────────────────────────────────────────

-- Issue a new license
CREATE OR REPLACE FUNCTION api.issue_license(
  p_tenant_id             uuid,
  p_tier                  ak_ip.license_tier,
  p_monthly_fee_cents     integer,
  p_licensed_faces        text[],
  p_kernel_migration_version integer,
  p_effective_date        date DEFAULT CURRENT_DATE
)
RETURNS ak_ip.licenses
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_license ak_ip.licenses;
BEGIN
  INSERT INTO ak_ip.licenses (
    tenant_id, license_tier, monthly_fee_cents,
    licensed_faces, kernel_migration_version, effective_date
  ) VALUES (
    p_tenant_id, p_tier, p_monthly_fee_cents,
    p_licensed_faces, p_kernel_migration_version, p_effective_date
  )
  RETURNING * INTO v_license;

  -- Write kernel event
  INSERT INTO ledger.events (tenant_id, event_type, payload)
  VALUES (
    p_tenant_id,
    'ak_ip.license_issued',
    jsonb_build_object(
      'license_id', v_license.id,
      'tier', p_tier,
      'monthly_fee_cents', p_monthly_fee_cents,
      'faces', p_licensed_faces,
      'kernel_version', p_kernel_migration_version
    )
  );

  RETURN v_license;
END;
$$;

-- Record a royalty collection and compute splits
CREATE OR REPLACE FUNCTION api.record_royalty(
  p_license_id            uuid,
  p_period_start          date,
  p_period_end            date,
  p_stripe_invoice_id     text DEFAULT NULL,
  p_stripe_payment_intent_id text DEFAULT NULL
)
RETURNS ak_ip.royalty_events
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_license     ak_ip.licenses;
  v_royalty     integer;
  v_kdh_fee     integer;
  v_ip_net      integer;
  v_sys_net     integer;
  v_event       ak_ip.royalty_events;
BEGIN
  SELECT * INTO v_license FROM ak_ip.licenses WHERE id = p_license_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'License % not found', p_license_id; END IF;

  -- Compute splits
  v_royalty := (v_license.monthly_fee_cents * v_license.royalty_rate_bps) / 10000;
  v_kdh_fee := (v_royalty * v_license.kdh_fee_rate_bps) / 10000;
  v_ip_net  := v_royalty - v_kdh_fee;
  v_sys_net := v_license.monthly_fee_cents - v_royalty;

  INSERT INTO ak_ip.royalty_events (
    license_id, tenant_id,
    period_start, period_end,
    gross_fee_cents, royalty_cents, kdh_fee_cents,
    ak_ip_net_cents, ak_systems_net_cents,
    state,
    stripe_invoice_id, stripe_payment_intent_id,
    collected_at
  ) VALUES (
    p_license_id, v_license.tenant_id,
    p_period_start, p_period_end,
    v_license.monthly_fee_cents, v_royalty, v_kdh_fee,
    v_ip_net, v_sys_net,
    'collected',
    p_stripe_invoice_id, p_stripe_payment_intent_id,
    now()
  )
  RETURNING * INTO v_event;

  -- Write ledger event
  INSERT INTO ledger.events (tenant_id, event_type, payload)
  VALUES (
    v_license.tenant_id,
    'ak_ip.royalty_collected',
    jsonb_build_object(
      'royalty_event_id', v_event.id,
      'license_id', p_license_id,
      'period_start', p_period_start,
      'gross_cents', v_license.monthly_fee_cents,
      'royalty_cents', v_royalty,
      'kdh_fee_cents', v_kdh_fee,
      'ak_ip_net_cents', v_ip_net,
      'ak_systems_net_cents', v_sys_net
    )
  );

  RETURN v_event;
END;
$$;

-- Mark royalty as remitted and seal a ledger receipt
CREATE OR REPLACE FUNCTION api.remit_royalty(p_royalty_event_id uuid)
RETURNS ak_ip.royalty_events
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_event   ak_ip.royalty_events;
  v_receipt ledger.receipts;
BEGIN
  SELECT * INTO v_event FROM ak_ip.royalty_events WHERE id = p_royalty_event_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Royalty event % not found', p_royalty_event_id; END IF;
  IF v_event.state != 'collected' THEN
    RAISE EXCEPTION 'Royalty event % is in state %, expected collected', p_royalty_event_id, v_event.state;
  END IF;

  -- Seal ledger receipt
  INSERT INTO ledger.receipts (tenant_id, event_type, payload, sealed_at)
  VALUES (
    v_event.tenant_id,
    'ak_ip.royalty_remitted',
    jsonb_build_object(
      'royalty_event_id', v_event.id,
      'license_id', v_event.license_id,
      'period_start', v_event.period_start,
      'ak_ip_net_cents', v_event.ak_ip_net_cents,
      'kdh_fee_cents', v_event.kdh_fee_cents,
      'remitted_at', now()
    ),
    now()
  )
  RETURNING * INTO v_receipt;

  -- Update royalty event
  UPDATE ak_ip.royalty_events
  SET state = 'remitted',
      remitted_at = now(),
      ledger_receipt_id = v_receipt.id,
      updated_at = now()
  WHERE id = p_royalty_event_id
  RETURNING * INTO v_event;

  RETURN v_event;
END;
$$;

-- ── RLS ───────────────────────────────────────────────────────
ALTER TABLE ak_ip.licenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE ak_ip.royalty_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE ak_ip.third_party_licenses ENABLE ROW LEVEL SECURITY;

-- Operators see only their own license
CREATE POLICY "tenant_licenses" ON ak_ip.licenses
  FOR SELECT USING (tenant_id = (current_setting('app.tenant_id', true))::uuid);

-- Operators see only their own royalty events (read-only)
CREATE POLICY "tenant_royalty_events" ON ak_ip.royalty_events
  FOR SELECT USING (tenant_id = (current_setting('app.tenant_id', true))::uuid);

-- Third-party licenses: no public access
CREATE POLICY "no_public_access" ON ak_ip.third_party_licenses
  FOR ALL USING (false);

-- ── Grants ────────────────────────────────────────────────────
GRANT SELECT ON ak_ip.licenses TO authenticated;
GRANT SELECT ON ak_ip.royalty_events TO authenticated;
GRANT SELECT ON ak_ip.entitlements TO authenticated;
GRANT SELECT ON ak_ip.royalty_summary TO authenticated;
GRANT EXECUTE ON FUNCTION api.issue_license TO authenticated;
GRANT EXECUTE ON FUNCTION api.record_royalty TO authenticated;
GRANT EXECUTE ON FUNCTION api.remit_royalty TO authenticated;

-- ── Updated_at trigger ────────────────────────────────────────
CREATE OR REPLACE FUNCTION ak_ip.set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TRIGGER trg_licenses_updated_at
  BEFORE UPDATE ON ak_ip.licenses
  FOR EACH ROW EXECUTE FUNCTION ak_ip.set_updated_at();

CREATE TRIGGER trg_royalty_events_updated_at
  BEFORE UPDATE ON ak_ip.royalty_events
  FOR EACH ROW EXECUTE FUNCTION ak_ip.set_updated_at();

-- ── Seed: register KDH itself as the founder tenant (no fee) ──
-- Run manually after applying migration, substituting the real KDH tenant_id:
-- SELECT api.issue_license(
--   p_tenant_id             => '<kdh-tenant-uuid>',
--   p_tier                  => 'enterprise',
--   p_monthly_fee_cents     => 0,           -- KDH is the founder, no charge
--   p_licensed_faces        => ARRAY['*'],  -- all faces
--   p_kernel_migration_version => 32
-- );
