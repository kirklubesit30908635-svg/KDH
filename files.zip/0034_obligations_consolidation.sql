-- ============================================================
-- Migration: 0034_obligations_consolidation.sql
-- Purpose:   Resolve the dual core.obligations schema conflict.
--
-- BACKGROUND:
--   Two versions of core.obligations exist in the cloud DB:
--   (A) From 0020_obligations_and_receipts.sql: uses status (open/sealed)
--   (B) From kernel_constitution_v1.sql: uses state (open/active/resolved)
--   The constitution migration was skipped on db reset because the
--   0020 version already existed. All RPCs must run against one schema.
--
-- STRATEGY (non-destructive):
--   1. Audit which columns actually exist right now.
--   2. Add the missing canonical columns if they don't exist.
--   3. Backfill: map old status values → new state values.
--   4. Create a compatibility view for any code still using old columns.
--   5. Update RPCs to use the canonical column names.
--   6. The old status column is retained (not dropped) to avoid breaking
--      any undetected references. A future migration can drop it.
--
-- CANONICAL SCHEMA (post-migration):
--   core.obligations.state  ENUM: open | active | resolved | breached | cancelled
--   core.obligations.state is the authoritative field.
--   core.obligations.status is retained as a deprecated alias.
-- ============================================================

-- ── Step 1: Ensure canonical enum type exists ────────────────
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'obligation_state'
                 AND typnamespace = (SELECT oid FROM pg_namespace WHERE nspname = 'core')) THEN
    CREATE TYPE core.obligation_state AS ENUM ('open', 'active', 'resolved', 'breached', 'cancelled');
  END IF;
END $$;

-- ── Step 2: Add canonical columns if missing ─────────────────
DO $$
BEGIN
  -- Add state column if it doesn't exist
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'state'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN state core.obligation_state;
  END IF;

  -- Add opened_at if missing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'opened_at'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN opened_at timestamptz;
  END IF;

  -- Add resolved_at if missing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'resolved_at'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN resolved_at timestamptz;
  END IF;

  -- Add breached_at if missing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'breached_at'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN breached_at timestamptz;
  END IF;

  -- Add due_at if missing (deadline for the obligation)
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'due_at'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN due_at timestamptz;
  END IF;

  -- Add resolution_payload if missing
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'resolution_payload'
  ) THEN
    ALTER TABLE core.obligations ADD COLUMN resolution_payload jsonb;
  END IF;
END $$;

-- ── Step 3: Backfill state from status where state is NULL ────
-- Maps old status values to canonical state values
UPDATE core.obligations
SET state = CASE
  WHEN status = 'open'   THEN 'open'::core.obligation_state
  WHEN status = 'sealed' THEN 'resolved'::core.obligation_state
  ELSE 'open'::core.obligation_state
END,
opened_at = COALESCE(opened_at, created_at)
WHERE state IS NULL
  AND EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations' AND column_name = 'status'
  );

-- ── Step 4: Set NOT NULL on state now that it's backfilled ────
DO $$
BEGIN
  -- Only alter if column exists and can be made NOT NULL
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'core' AND table_name = 'obligations'
      AND column_name = 'state' AND is_nullable = 'YES'
  ) THEN
    -- Set a default so future inserts don't break
    ALTER TABLE core.obligations ALTER COLUMN state SET DEFAULT 'open';
    -- Make NOT NULL only if all rows have a value
    IF NOT EXISTS (SELECT 1 FROM core.obligations WHERE state IS NULL) THEN
      ALTER TABLE core.obligations ALTER COLUMN state SET NOT NULL;
    END IF;
  END IF;
END $$;

-- ── Step 5: Compatibility view ────────────────────────────────
-- Any code still using status/sealed can use this view
CREATE OR REPLACE VIEW core.obligations_legacy AS
SELECT
  *,
  CASE state
    WHEN 'open'      THEN 'open'
    WHEN 'active'    THEN 'open'
    WHEN 'resolved'  THEN 'sealed'
    WHEN 'breached'  THEN 'sealed'
    WHEN 'cancelled' THEN 'sealed'
  END AS status_compat
FROM core.obligations;

-- ── Step 6: Replace open_obligation RPC ──────────────────────
-- Canonical version using state column
CREATE OR REPLACE FUNCTION api.open_obligation(
  p_tenant_id     uuid,
  p_object_id     uuid,
  p_obligation_type text,
  p_payload       jsonb DEFAULT '{}',
  p_due_at        timestamptz DEFAULT NULL
)
RETURNS core.obligations
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_obligation core.obligations;
  v_event_id   uuid;
BEGIN
  -- Verify object exists for this tenant
  IF NOT EXISTS (SELECT 1 FROM core.objects WHERE id = p_object_id AND tenant_id = p_tenant_id) THEN
    RAISE EXCEPTION 'Object % not found for tenant %', p_object_id, p_tenant_id;
  END IF;

  INSERT INTO core.obligations (
    tenant_id, object_id, obligation_type, state,
    payload, opened_at, due_at
  ) VALUES (
    p_tenant_id, p_object_id, p_obligation_type, 'open',
    p_payload, now(), p_due_at
  ) RETURNING * INTO v_obligation;

  -- Write ledger event
  INSERT INTO ledger.events (tenant_id, event_type, payload)
  VALUES (
    p_tenant_id,
    'obligation.opened',
    jsonb_build_object(
      'obligation_id', v_obligation.id,
      'object_id', p_object_id,
      'obligation_type', p_obligation_type,
      'due_at', p_due_at
    )
  ) RETURNING id INTO v_event_id;

  RETURN v_obligation;
END;
$$;

-- ── Step 7: Replace resolve_obligation RPC ────────────────────
CREATE OR REPLACE FUNCTION api.resolve_obligation(
  p_obligation_id uuid,
  p_resolution_payload jsonb DEFAULT '{}'
)
RETURNS core.obligations
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_obligation  core.obligations;
  v_receipt     ledger.receipts;
BEGIN
  SELECT * INTO v_obligation FROM core.obligations WHERE id = p_obligation_id;
  IF NOT FOUND THEN RAISE EXCEPTION 'Obligation % not found', p_obligation_id; END IF;

  IF v_obligation.state NOT IN ('open', 'active') THEN
    RAISE EXCEPTION 'Obligation % is in state %, cannot resolve', p_obligation_id, v_obligation.state;
  END IF;

  -- Seal a receipt
  INSERT INTO ledger.receipts (tenant_id, event_type, payload, sealed_at)
  VALUES (
    v_obligation.tenant_id,
    'obligation.resolved',
    jsonb_build_object(
      'obligation_id', v_obligation.id,
      'object_id', v_obligation.object_id,
      'obligation_type', v_obligation.obligation_type,
      'opened_at', v_obligation.opened_at,
      'resolved_at', now(),
      'resolution', p_resolution_payload
    ),
    now()
  ) RETURNING * INTO v_receipt;

  -- Update obligation to resolved
  UPDATE core.obligations
  SET state = 'resolved',
      resolved_at = now(),
      resolution_payload = p_resolution_payload,
      updated_at = now()
  WHERE id = p_obligation_id
  RETURNING * INTO v_obligation;

  RETURN v_obligation;
END;
$$;

-- ── Step 8: Breach detection function ────────────────────────
-- Call on a schedule (pg_cron or via Next.js cron) to auto-breach expired obligations
CREATE OR REPLACE FUNCTION api.breach_overdue_obligations(p_tenant_id uuid DEFAULT NULL)
RETURNS integer
LANGUAGE plpgsql SECURITY DEFINER
AS $$
DECLARE
  v_count integer := 0;
  v_obligation core.obligations;
BEGIN
  FOR v_obligation IN
    SELECT * FROM core.obligations
    WHERE state IN ('open', 'active')
      AND due_at IS NOT NULL
      AND due_at < now()
      AND (p_tenant_id IS NULL OR tenant_id = p_tenant_id)
  LOOP
    UPDATE core.obligations
    SET state = 'breached',
        breached_at = now(),
        updated_at = now()
    WHERE id = v_obligation.id;

    INSERT INTO ledger.events (tenant_id, event_type, payload)
    VALUES (
      v_obligation.tenant_id,
      'obligation.breached',
      jsonb_build_object(
        'obligation_id', v_obligation.id,
        'object_id', v_obligation.object_id,
        'obligation_type', v_obligation.obligation_type,
        'due_at', v_obligation.due_at,
        'breached_at', now()
      )
    );

    v_count := v_count + 1;
  END LOOP;

  RETURN v_count;
END;
$$;

-- ── Grants ────────────────────────────────────────────────────
GRANT SELECT ON core.obligations_legacy TO authenticated;
GRANT EXECUTE ON FUNCTION api.open_obligation TO authenticated;
GRANT EXECUTE ON FUNCTION api.resolve_obligation TO authenticated;
GRANT EXECUTE ON FUNCTION api.breach_overdue_obligations TO authenticated;

-- ── Verification query (run after migration to confirm) ───────
-- SELECT
--   COUNT(*) FILTER (WHERE state IS NULL) AS null_states,
--   COUNT(*) FILTER (WHERE state = 'open') AS open_count,
--   COUNT(*) FILTER (WHERE state = 'resolved') AS resolved_count,
--   COUNT(*) FILTER (WHERE state = 'breached') AS breached_count
-- FROM core.obligations;
--
-- Expected: null_states = 0
