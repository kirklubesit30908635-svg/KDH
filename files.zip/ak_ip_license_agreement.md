# AutoKirk Kernel License Agreement

**Agreement Type:** Operator Software License
**Licensor:** AutoKirk IP Holdings LLC ("Licensor")
**Sub-Licensor:** AutoKirk Systems LLC ("Distributor")
**Licensee:** _______________________________ ("Operator")
**Effective Date:** _______________
**License Tier:** [ ] Seed  [ ] Operator  [ ] Enterprise

---

## 1. Definitions

**"Kernel"** means the AutoKirk enforcement operating system, including the immutable schema layer (core.objects, core.obligations, ledger.events, ledger.receipts), all RPCs, the Weight Engine, the Command/Policy layer, and any Faces licensed hereunder, as maintained by Licensor in version-controlled migrations.

**"Face"** means a market-specific deployment module built on top of the Kernel that provides vocabulary, UI, and enforcement logic for a particular business vertical.

**"Licensed Face(s)"** means the Face(s) identified in Schedule A of this Agreement.

**"Tenant"** means Operator's isolated instance within the AutoKirk platform, governed by Operator's unique `tenant_id` in the Kernel's identity schema.

**"Authorized Location(s)"** means the business location(s) identified in Schedule A.

**"Kernel Version"** means the specific migration chain version pinned at the time of License issuance, identified by the highest applied migration number.

---

## 2. License Grant

**2.1 Grant.** Subject to the terms of this Agreement and payment of all fees, Licensor (through Distributor) grants Operator a limited, non-exclusive, non-transferable, non-sublicensable license to:

(a) Access and use the Kernel through Operator's Tenant;
(b) Use the Licensed Face(s) for Operator's internal business operations at the Authorized Location(s);
(c) Submit data to and retrieve data from Operator's Tenant via the Kernel's authorized API surface.

**2.2 Restrictions.** Operator shall not:

(a) Copy, modify, reverse engineer, decompile, or disassemble the Kernel or any Face;
(b) Access any other Tenant's data or attempt to circumvent Tenant isolation;
(c) Use the Kernel to build or distribute a competing product;
(d) Transfer, sublicense, or assign this Agreement without Licensor's written consent;
(e) Remove or obscure any proprietary notices embedded in the Kernel or Faces;
(f) Access the Kernel through any means other than the authorized API surface.

**2.3 Kernel Immutability.** Operator acknowledges that the Kernel's core schema, doctrine laws, and enforcement chain are immutable by design. Operator has no right to modify the Kernel's core tables, RPCs, or enforcement logic.

---

## 3. Fees and Royalties

**3.1 Monthly License Fee.** Operator shall pay Distributor the Monthly License Fee set forth in Schedule A, due on the first business day of each calendar month.

**3.2 Royalty Flow.** Operator acknowledges that Distributor remits a royalty of twenty percent (20%) of all Monthly License Fees to Licensor (AutoKirk IP Holdings LLC) as the IP owner. This royalty is embedded in Operator's fee and does not represent an additional charge.

**3.3 Late Payment.** Fees not received within ten (10) days of the due date accrue interest at 1.5% per month.

**3.4 Fee Adjustments.** Licensor may adjust fees upon sixty (60) days written notice. Operator may terminate without penalty within thirty (30) days of receiving a fee adjustment notice.

---

## 4. Term and Termination

**4.1 Term.** This Agreement commences on the Effective Date and continues on a month-to-month basis unless terminated.

**4.2 Termination for Convenience.** Either party may terminate this Agreement upon thirty (30) days written notice.

**4.3 Termination for Cause.** Licensor or Distributor may terminate immediately upon written notice if Operator:

(a) Breaches any material term and fails to cure within ten (10) days of written notice;
(b) Fails to pay any fee within fifteen (15) days of its due date;
(c) Attempts to access another Tenant's data or circumvent Kernel security;
(d) Becomes insolvent or files for bankruptcy.

**4.4 Effect of Termination.** Upon termination, Operator's Tenant access is revoked. Operator may request an export of its own Tenant data within thirty (30) days of termination. Licensor retains all data in the append-only ledger as required for audit purposes.

---

## 5. Data and Privacy

**5.1 Tenant Isolation.** Operator's data is scoped to Operator's Tenant via Row Level Security enforced at the database level. Licensor does not access Operator's Tenant data except for platform maintenance, security, and legal compliance purposes.

**5.2 Ledger Immutability.** Operator acknowledges that all events written to `ledger.events` and receipts written to `ledger.receipts` are append-only and cannot be deleted or modified by any party, including Licensor. This is a foundational design property of the Kernel.

**5.3 Data Ownership.** Operator owns the business data it inputs into its Tenant. Licensor owns the Kernel, schema, and enforcement infrastructure.

---

## 6. Intellectual Property

All right, title, and interest in the Kernel, all Faces, the AutoKirk name and marks, and all documentation remain the exclusive property of AutoKirk IP Holdings LLC. No license is granted except as expressly stated herein. Operator's use of the Kernel does not grant Operator any ownership interest in any component thereof.

---

## 7. Warranties and Disclaimers

**7.1 Licensor Warranty.** Licensor warrants that it has the right to license the Kernel as set forth herein and that the Kernel will perform materially in accordance with its documentation.

**7.2 Disclaimer.** THE KERNEL AND ALL FACES ARE PROVIDED "AS IS" EXCEPT AS EXPRESSLY WARRANTED HEREIN. LICENSOR DISCLAIMS ALL IMPLIED WARRANTIES, INCLUDING MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND NON-INFRINGEMENT.

---

## 8. Limitation of Liability

IN NO EVENT SHALL LICENSOR OR DISTRIBUTOR BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES. LICENSOR'S TOTAL LIABILITY SHALL NOT EXCEED THE FEES PAID BY OPERATOR IN THE THREE (3) MONTHS PRECEDING THE CLAIM.

---

## 9. Governing Law and Disputes

This Agreement is governed by the laws of [STATE]. Any dispute shall be resolved by binding arbitration under the rules of the American Arbitration Association, with proceedings in [CITY, STATE].

---

## Schedule A — License Configuration

| Field | Value |
|---|---|
| Operator legal name | |
| DBA / trade name | |
| License tier | Seed / Operator / Enterprise |
| Licensed Face(s) | |
| Authorized Location(s) | |
| Kernel Version at issuance | Migration # ______ |
| Monthly License Fee | $ |
| Billing cycle start | |
| Tenant ID (assigned at provisioning) | |

---

**LICENSOR:**
AutoKirk IP Holdings LLC

By: _____________________________ Title: _________________ Date: _______________

**DISTRIBUTOR:**
AutoKirk Systems LLC

By: _____________________________ Title: _________________ Date: _______________

**OPERATOR:**
_______________________________

By: _____________________________ Title: _________________ Date: _______________

---

*This document was prepared as an internal template. Have a licensed attorney review before execution.*
