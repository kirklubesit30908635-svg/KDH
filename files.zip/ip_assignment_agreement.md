# Intellectual Property Assignment Agreement

**Effective Date:** _______________

**Assignor:** Chase Kirk, an individual, and Kirk Digital Holdings LLC, a limited liability company ("Assignor")

**Assignee:** AutoKirk IP Holdings LLC, a limited liability company ("Assignee")

---

## 1. Recitals

Assignor has developed or caused to be developed certain software, schemas, architectural designs, documentation, and related intellectual property constituting the AutoKirk kernel platform (the "IP Assets"). Assignor desires to assign all right, title, and interest in the IP Assets to Assignee, and Assignee desires to accept such assignment, on the terms set forth herein.

---

## 2. Assigned IP Assets

Assignor hereby irrevocably assigns to Assignee all right, title, and interest, including all intellectual property rights, in and to the following (collectively, the "IP Assets"):

**2.1 Software and Code**
- The AutoKirk kernel codebase, including all source files, compiled binaries, and build artifacts, as maintained in the GitHub repository `kirklubesit30908635-svg/KDH` at local path `C:\Users\chase kirk\autokirk-kernel`
- All Next.js application code, Supabase migration files, API route handlers, middleware, and component libraries constituting the AutoKirk platform
- The Stripe webhook integration, subscription gate, and billing pipeline code

**2.2 Database Schema and Architecture**
- The complete migration chain (migrations 0001 through 0100 and all subsequent migrations), including:
  - Core schema: `core.tenants`, `core.workspaces`, `core.memberships`, `core.objects`, `core.obligations`
  - Ledger schema: `ledger.events`, `ledger.receipts`
  - API schema: all RPCs including `acknowledge_object`, `open_obligation`, `resolve_obligation`
  - Registry, intelligence, ingest, and governance schemas
- The Kernel Constitution V1 architecture and all subsequent constitutional versions
- The ak_governance elimination registry and managed surfaces framework

**2.3 System Design and Doctrine**
- The Five Foundational Doctrine Laws of the AutoKirk kernel
- The OS layer map: kernel, guard, governance, intelligence, sovereign core, contract surface, and all Face definitions
- The canonical kernel event pipeline: Event → Object → Obligation → Command → Closure → Receipt → Integrity
- The Weight Engine design, integrity scoring formula, and all scoring methodology documentation
- The Command/Policy layer architecture and kernel_command_policy_v1 design

**2.4 Face Definitions and Market Deployments**
- Advertising Accountability Face (#004) including the FRL readiness framework
- Dealership/Marine Face including the Old Salt Marine operator console deployment
- All future Face definitions originating from the AutoKirk kernel architecture

**2.5 Brand, Marks, and Domain**
- The "AutoKirk" name and mark
- The domain autokirk.com and all associated subdomains
- All visual design systems, UI component libraries, and the Bloomberg terminal aesthetic design language

**2.6 Documentation**
- All system design reference documents, architectural diagrams, and internal documentation describing the AutoKirk platform

---

## 3. Consideration

In consideration for this assignment, Assignee agrees to:

(a) Grant back to Assignor and to AutoKirk Systems LLC a perpetual, royalty-bearing license to use, deploy, and distribute the IP Assets in accordance with the Intercompany License Agreement between Assignee and AutoKirk Systems LLC; and

(b) Pay Assignor a governance fee equal to ten percent (10%) of all royalty revenue received by Assignee from any licensee, payable monthly.

---

## 4. Representations and Warranties

Assignor represents and warrants that:

(a) Assignor is the sole and exclusive owner of the IP Assets and has full right and authority to assign them;

(b) The IP Assets are free and clear of all liens, claims, and encumbrances;

(c) To Assignor's knowledge, the IP Assets do not infringe any third-party intellectual property rights;

(d) No portion of the IP Assets has been previously assigned, transferred, or licensed in a manner inconsistent with this Agreement.

---

## 5. Further Assurances

Assignor agrees to execute any additional documents, including copyright registration applications, patent applications, or other filings reasonably requested by Assignee to perfect, record, or enforce the assigned rights.

---

## 6. Governing Law

This Agreement is governed by the laws of the state of [STATE], without regard to conflict of laws principles.

---

## 7. Entire Agreement

This Agreement constitutes the entire agreement between the parties with respect to the subject matter hereof and supersedes all prior negotiations, representations, and agreements.

---

**ASSIGNOR:**

Chase Kirk, Individual

Signature: _______________________________ Date: _______________

Kirk Digital Holdings LLC

By: _____________________________ Title: _________________ Date: _______________

---

**ASSIGNEE:**

AutoKirk IP Holdings LLC

By: _____________________________ Title: _________________ Date: _______________

---

*This document was prepared as an internal template. Have a licensed attorney review before execution.*
